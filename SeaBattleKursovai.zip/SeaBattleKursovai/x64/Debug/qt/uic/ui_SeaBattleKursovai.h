/********************************************************************************
** Form generated from reading UI file 'SeaBattleKursovai.ui'
**
** Created by: Qt User Interface Compiler version 6.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEABATTLEKURSOVAI_H
#define UI_SEABATTLEKURSOVAI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SeaBattleKursovaiClass
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SeaBattleKursovaiClass)
    {
        if (SeaBattleKursovaiClass->objectName().isEmpty())
            SeaBattleKursovaiClass->setObjectName("SeaBattleKursovaiClass");
        SeaBattleKursovaiClass->resize(600, 400);
        centralWidget = new QWidget(SeaBattleKursovaiClass);
        centralWidget->setObjectName("centralWidget");
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(220, 100, 75, 24));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(220, 120, 75, 24));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(220, 140, 75, 24));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(220, 160, 75, 24));
        SeaBattleKursovaiClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SeaBattleKursovaiClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 600, 22));
        SeaBattleKursovaiClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(SeaBattleKursovaiClass);
        mainToolBar->setObjectName("mainToolBar");
        SeaBattleKursovaiClass->addToolBar(Qt::ToolBarArea::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(SeaBattleKursovaiClass);
        statusBar->setObjectName("statusBar");
        SeaBattleKursovaiClass->setStatusBar(statusBar);

        retranslateUi(SeaBattleKursovaiClass);

        QMetaObject::connectSlotsByName(SeaBattleKursovaiClass);
    } // setupUi

    void retranslateUi(QMainWindow *SeaBattleKursovaiClass)
    {
        SeaBattleKursovaiClass->setWindowTitle(QCoreApplication::translate("SeaBattleKursovaiClass", "SeaBattleKursovai", nullptr));
        pushButton->setText(QCoreApplication::translate("SeaBattleKursovaiClass", "PushButton", nullptr));
        pushButton_2->setText(QCoreApplication::translate("SeaBattleKursovaiClass", "PushButton", nullptr));
        pushButton_3->setText(QCoreApplication::translate("SeaBattleKursovaiClass", "PushButton", nullptr));
        pushButton_4->setText(QCoreApplication::translate("SeaBattleKursovaiClass", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SeaBattleKursovaiClass: public Ui_SeaBattleKursovaiClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEABATTLEKURSOVAI_H
