#include "gameobserver.h"

GameObserver::GameObserver(QObject* parent)
    : QObject(parent)
{
}